# MediTrack — Medication Companion

A responsive, clickable student prototype for the AI in Medicine mid-term project.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a browser. No build tools or dependencies are needed.

## Features
- Add medicines with a dose/instruction label and reminder time
- Mark medication entries as taken or undo the action
- Track simple symptom notes and severity
- Daily habit check-in
- Saves demo data in the browser's local storage
- Responsive layout for desktop and mobile
- Privacy and medical-use limitations are shown in the app

## Important limitations
This is an educational prototype, not a medical device. It does not send real notifications, use clinical AI, sync to a server, or provide medical advice. Do not enter real sensitive health information into a demo.

## Publish with GitHub Pages
1. Create a new repository on GitHub (for example, `meditrack-app`).
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under the build/deployment settings, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. After GitHub finishes publishing, open the Pages URL shown in Settings → Pages.

## Project summary
**Problem:** People can forget doses or struggle to keep a simple record of symptoms.
**Users:** Patients and caregivers.
**Proposed solution:** A simple medication schedule and personal symptom log.
**Data protection:** This prototype stores data only in the current browser using local storage; it does not send data to a server.
**AI/API:** No AI or external API is used in this demo. AI could be explored in a future version only with clinical validation, consent, and strong privacy safeguards.
